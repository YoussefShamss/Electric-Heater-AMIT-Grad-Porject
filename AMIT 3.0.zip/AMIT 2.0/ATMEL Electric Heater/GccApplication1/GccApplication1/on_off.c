/*
 * on_off.c
 *
 *  Created on: 23 Dec 2022
 *      Author: Shams
 */
#include"on_off.h"

void ON_Init(void)
{
	SetPinDir(Group_B,PIN2, PIN_INPUT); //on/off
	MCUCSR|=(1<<6);
	GICR|=(1<<INT2);
}

void change_status(uint8* status, uint8* flag, uint8* tempsettingsstatus, uint8* buttoncounter) //on/off status
{
	if((PINB>>2)&0x01)
	{
		_delay_ms(50);
		if((PINB>>2)&0x01)
		{
			if(*status==1)
			{
				*status=0;
				*tempsettingsstatus = 0;
				*buttoncounter = 0;
			}
			else
			*status = 1;
			*flag = 1;
		}
	}
}

