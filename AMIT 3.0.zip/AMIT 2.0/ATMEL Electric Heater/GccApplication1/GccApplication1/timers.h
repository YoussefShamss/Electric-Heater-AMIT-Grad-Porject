/*
 * timers.h
 *
 *  Created on: 21 Dec 2022
 *      Author: Shams
 */

#ifndef TIMERS_H_
#define TIMERS_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "std_types.h"

void Timer0Init(void);
void Timer0Reset(void);
void Timer0Disable(uint8*);

void Timer2Init(void);
void Timer2Reset(void);
void Timer2Disable(uint8*);

void Timer1Init(uint8*, uint8*);
void Timer1Reset(void);
void Timer1Disable(void);


#endif /* TIMERS_H_ */
