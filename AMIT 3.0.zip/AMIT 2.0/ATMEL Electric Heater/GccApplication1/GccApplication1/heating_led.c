	
	#include "heating_led.h"
	#include <util/delay.h>


	void led_init()
	{
		SetPinDir(Group_D,PIN1, PIN_OUTPUT);
		SetPinVal(Group_D,PIN1, PIN_LOW);
	}

	void led_heatingBlink(uint16*count,uint8 heater_status)
	{
		*count = *count +1;
		if(heater_status == 1)
		{
			*count = *count +1;
			if (*count >= 15)
			{
				*count = 0;
				TOG_BIT(PORTD,1);
			}
		}
	}

	void led_coolingON()
	{
		SetPinVal(Group_D,PIN1, PIN_HIGH);
	}

	void led_disable()
	{
		SetPinVal(Group_D,PIN1, PIN_LOW);
	}