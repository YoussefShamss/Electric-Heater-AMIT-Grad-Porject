/*
 * up_down.c
 *
 *  Created on: Dec 19, 2022
 *      Author: main
 */


#include "up_down.h"

void button_init()
{
	SetPinDir(Group_D,PIN2, PIN_INPUT); //up button
	SetPinDir(Group_D,PIN3, PIN_INPUT); //down button
	//SetPinDir(Group_B,PIN2, PIN_INPUT); //on/off
	SREG |=(1<<7); //global interrupt
	GICR|=(1<<INT0)|(1<<INT1);
	MCUCR |=(1<<1)|(1<<0)|(1<<2)|(1<<3); //rising edge
}

void button_up(uint16 *set_temp, uint8 *counter, uint8 *status, uint8* flag)
{
	if((PIND>>2)&0x01)
		{
			_delay_ms(100);
			if((PIND>>2)&0x01)
			{
				while((PIND>>2)&0x01){}
				*counter = *counter + 1;
				*flag = 1;

				if( *counter >= 2 ) // Check to apply the temperature increase logic
				{
					if(*set_temp<=70) // Max temperature 75
					{
						*set_temp=(*set_temp)+5; // Increment by 5
						DisplayTemp(*set_temp);
					}
				}
				else // Enter Temperature Settings Mode
				{
					*status = 1;
				}
			}
		}
}
void button_down(uint16 *set_temp, uint8 *counter, uint8 *status,  uint8* flag)
{
	if((PIND>>3)&0x01)
	{
		_delay_ms(100);
		if((PIND>>3)&0x01)
		{
			while((PIND>>3)&0x01){}
			*counter = *counter + 1; //Incrementing the counter
			*flag = 1;

			if( *counter >= 2 ) // Check to apply the temperature increase logic
			{
				if(*set_temp>=40) // Max temperature 35
				{
					*set_temp=(*set_temp)-5;
					DisplayTemp(*set_temp);
				}
			}
			else // Enter Temperature Settings Mode
			{
				*status = 1;
			}
		}
	}
}

void exittempset_mode(uint8 *status, uint8 *counter)
{
	*counter = 0; // Reset Counter
	*status = 0;  // Return to Normal Mode
}

void button_disable(void)
{
	SetPinDir(Group_D,PIN2, PIN_OUTPUT); //up button
	SetPinDir(Group_D,PIN3, PIN_OUTPUT); //down button
}
