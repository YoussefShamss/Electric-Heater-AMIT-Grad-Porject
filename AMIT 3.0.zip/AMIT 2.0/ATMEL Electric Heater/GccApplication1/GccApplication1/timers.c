/*
 * timers.c
 *
 *  Created on: 21 Dec 2022
 *      Author: Shams
 */

#include"timers.h"


void Timer0Init(void)
{
	TCNT0 = 0;
	TCCR0 |= (1<<2)|(1<<0);  // Normal Mode, OC0 Disconnected, Prescaler = 1024
	TIMSK &= 0b11111101; // Disable Output Compare Match Interrupts
	TIMSK |= 0b00000001; // Enable Timer0 Overflow Interrupt
	TIFR |= (1<<TOV0);
}

void Timer0Reset(void)
{
	TCNT0 = 0;
	TIFR |= (1<<TOV0);
}

void Timer0Disable(uint8* counter1)
{
	TCCR0 = 0x00;
	counter1 = 0;
}

void Timer2Init(void)
{
	TCNT2 = 10;        // Start Timer2 at 127 so that it doesn't conflict with Timer0
	TCCR2 = 0b00000101;  // Normal Mode, OC2 Disconnected, Prescaler = 1024
	TIMSK &= 0b01111111; // Disable Output Compare Match Interrupts
	TIMSK |= 0b01000000; // Enable Timer2 Overflow Interrupt
	TIFR |= (1<<TOV2);
}

void Timer2Reset(void)
{
	TCNT2 = 0x7F;
	TIFR |= (1<<TOV2);
}

void Timer2Disable(uint8* count)
{
	*count = 0;
	TCCR2 = 0x00;
}

void Timer1Init(uint8* status, uint8* flag)
{
	if(*status==1 && *flag ==1)
	{
		TCNT1 = 0x00;
		TCCR1A = 0b00000000; // Normal Mode
		TCCR1B = 0b00000011; // Prescaler = 64
		TIMSK &= 0b11000111; // Disable Input Capture Interrupt & Output Compare Match Interrupt
		TIMSK |= (1<<TOIE1); // Enabling Overflow Interrupts
		*flag = 0;
	}
}

void Timer1Reset(void)
{
	TCNT1 = 0x00;
	TIFR |= (1<<TOV1);
}

void Timer1Disable(void)
{
	TCCR1A = 0x00;
	TCCR1B = 0x00;
}

