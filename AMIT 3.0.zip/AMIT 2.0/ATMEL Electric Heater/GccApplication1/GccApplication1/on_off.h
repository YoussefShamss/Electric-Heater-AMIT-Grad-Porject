/*
 * on_off.h
 *
 *  Created on: 23 Dec 2022
 *      Author: Shams
 */

#ifndef ON_OFF_H_
#define ON_OFF_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "std_types.h"
#include "bit_maths.h"
#include "DIO_Interface.h"

void ON_Init(void);
void change_status(uint8*, uint8*, uint8*, uint8*);

#endif /* ON_OFF_H_ */
