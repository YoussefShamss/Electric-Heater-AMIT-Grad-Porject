
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include "temp_elements.h"
#include "temp_sensor.h"
#include "up_down.h"
#include "heating_led.h"
#include "seven_seg.h"
#include "timers.h"
#include "on_off.h"
#include "External_EEPROM.h"
#define F_CPU 16000000UL

int temperature;
uint16 set_temp=60;
uint16* t=& set_temp;

uint8 ButtonCounter = 0;
uint8 Timer0Counter = 0;
uint16 Timer2Counter = 0;
uint8 Timer1Counter = 0;
uint8 TempCount = 0;

uint8 TempSettingsStatus = 0; // For Temperature Setting Mode
uint8 HeaterStatus = 0;
uint8 On_Off_Status = 0;

uint8 Timer1Flag = 0;
uint8 DispFlag = 0;

int main(void)
{
	EEPROM_Init();
	button_init();
	sensor_Init();
	led_init();
	button_init();
	ON_Init();
	Timer2Init();
	sei();   
	
	while (1)
	{
		if(On_Off_Status == 1)
		{
			temperature=temp_calc();
			temp_regulation(temperature,set_temp,&HeaterStatus);
			
			if(TempSettingsStatus == 1)
			{
				DisplayTemp(set_temp);
			}
			else if(TempSettingsStatus == 0)
			{
				DisplayTemp(temperature);
			}
			
		}
		else if (On_Off_Status == 0)
		{
			SevenSegDisable();
			heating_element_disable();
			cooling_element_disable();
			led_disable();
			Timer0Disable(&Timer0Counter);
			//Timer2Disable(&Timer2Counter);
			EEPROM_Read_Byte(0x0311,&set_temp);
		}
	}
}

ISR(INT0_vect)
{
	if(On_Off_Status==1)
	{
		button_up(t, &ButtonCounter, &TempSettingsStatus, &Timer1Flag);
		EEPROM_Write_Byte(0x0311,set_temp);
		Timer1Init(&TempSettingsStatus, &Timer1Flag);
		if(TempSettingsStatus == 1)
		{
			Timer0Init();
		}
	}
}

ISR(INT1_vect)
{
	if(On_Off_Status==1)
	{
		button_down(t, &ButtonCounter, &TempSettingsStatus, &Timer1Flag);
		EEPROM_Write_Byte(0x0311,set_temp);
		Timer1Init(&TempSettingsStatus, &Timer1Flag);
		if(TempSettingsStatus == 1)
		{
			Timer0Init();
		}
	}
}

ISR(INT2_vect)
{
	change_status(&On_Off_Status, &DispFlag, &TempSettingsStatus, &ButtonCounter);
	 if(On_Off_Status == 0)
	{
		Timer0Disable(&Timer0Counter);
		SetPinDir(Group_B,PIN0, PIN_INPUT); // Disabling the heating element
		SetPinDir(Group_D,PIN0, PIN_INPUT); // Disabling the cooling element
		
	}
}

ISR(TIMER0_OVF_vect) // (1sec) Seven Segment Blinking
{
	SevenSegBlink(&Timer0Counter, TempSettingsStatus);
}

ISR(TIMER1_OVF_vect) // (5s) Temperature Settings Mode
// DONE
{
	PORTC &= (~(1<<6));  // To make sure that the final state of the seven segment is always on
	TempSettingsStatus = 0;
	ButtonCounter = 0;
	Timer1Disable();
}

ISR(TIMER2_OVF_vect) // (1sec) Heating Element LED
{
	led_heatingBlink(&Timer2Counter, HeaterStatus);
}

